import Link from 'next/link';
import type { Hospital } from '@/lib/public-api';
import { t, truncate } from '@/lib/utils';
import { ShieldPlus, ArrowRight } from 'lucide-react';

export default function HospitalCard({ hospital }: { hospital: Hospital }) {
  const color = hospital.brandColor || '#175cdd'; // Fallback to accent color
  
  return (
    <div className="department-highlight bg-white p-8 rounded-card border border-gray-100 hover:border-transparent hover:shadow-floating transition-all duration-300 h-full flex flex-col group relative overflow-hidden" data-aos="fade-up">
      {/* Top accent line */}
      <div className="absolute top-0 left-0 w-full h-1" style={{ backgroundColor: color }} />
      
      <div className="highlight-icon w-16 h-16 rounded-full flex items-center justify-center mb-6 transition-transform duration-300 group-hover:scale-110" style={{ backgroundColor: `${color}15`, color: color }}>
        {hospital.logoUrl ? (
          <img src={hospital.logoUrl} alt="" className="w-10 h-10 object-contain" />
        ) : (
          <ShieldPlus className="w-8 h-8" />
        )}
      </div>
      
      <h4 className="text-xl font-bold text-heading font-montserrat mb-3">{t(hospital.name)}</h4>
      
      <p className="text-default font-cairo mb-6 flex-1 text-sm leading-relaxed">
        {truncate(t(hospital.shortDescription), 120)}
      </p>
      
      <Link href={`/hospitals/${hospital.slug}`} className="highlight-cta inline-flex items-center gap-2 font-bold font-cairo transition-colors mt-auto" style={{ color: color }}>
        اكتشف المستشفى <ArrowRight className="w-4 h-4 rtl:rotate-180" />
      </Link>
    </div>
  );
}
