'use client';

import { useState, useEffect } from 'react';
import type { Hospital, MedicalCenter, Doctor } from '@/lib/public-api';
import { getBookingQuestions } from '@/lib/public-api';
import { t } from '@/lib/utils';

const API_BASE = process.env.NEXT_PUBLIC_API_BASE_URL || 'http://localhost:4000/api/v1';

interface Props {
  hospitals: Hospital[];
  centers: MedicalCenter[];
  doctors: Doctor[];
  defaultHospitalId?: string;
  defaultCenterId?: string;
  defaultDoctorId?: string;
}

export default function AppointmentForm({ hospitals, centers, doctors, defaultHospitalId, defaultCenterId, defaultDoctorId }: Props) {
  const [form, setForm] = useState({
    name: '',
    phone: '',
    email: '',
    hospitalId: defaultHospitalId || '',
    medicalCenterId: defaultCenterId || '',
    doctorId: defaultDoctorId || '',
    preferredDate: '',
    message: '',
  });
  
  const [questions, setQuestions] = useState<any[]>([]);
  const [answers, setAnswers] = useState<Record<string, any>>({});
  
  const [status, setStatus] = useState<'idle' | 'loading' | 'success' | 'error'>('idle');
  const [errMsg, setErrMsg] = useState('');

  // Fetch dynamic questions when center changes
  useEffect(() => {
    if (form.medicalCenterId) {
      getBookingQuestions(form.medicalCenterId).then((res) => {
        if (res?.data) {
          setQuestions(res.data);
          // Initialize answers
          const initialAnswers: Record<string, any> = {};
          res.data.forEach((q: any) => {
            if (q.questionType === 'checkbox') initialAnswers[q.id] = [];
            else initialAnswers[q.id] = '';
          });
          setAnswers(initialAnswers);
        }
      }).catch(console.error);
    } else {
      setQuestions([]);
      setAnswers({});
    }
  }, [form.medicalCenterId]);

  function onChange(e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement | HTMLTextAreaElement>) {
    setForm(prev => ({ ...prev, [e.target.name]: e.target.value }));
  }
  
  function onAnswerChange(qId: string, val: any) {
    setAnswers(prev => ({ ...prev, [qId]: val }));
  }

  async function onSubmit(e: React.FormEvent) {
    e.preventDefault();
    setStatus('loading');
    try {
      const body: Record<string, any> = { name: form.name, phone: form.phone };
      if (form.email) body.email = form.email;
      if (form.hospitalId) body.hospitalId = form.hospitalId;
      if (form.medicalCenterId) body.medicalCenterId = form.medicalCenterId;
      if (form.doctorId) body.doctorId = form.doctorId;
      if (form.preferredDate) body.preferredDate = new Date(form.preferredDate).toISOString();
      if (form.message) body.message = form.message;
      if (Object.keys(answers).length > 0) body.answers = answers;

      const res = await fetch(`${API_BASE}/appointments`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(body),
      });
      if (!res.ok) {
        const data = await res.json();
        throw new Error(data?.error?.message || 'حدث خطأ أثناء الإرسال');
      }
      setStatus('success');
    } catch (err: any) {
      setErrMsg(err.message || 'حدث خطأ، يرجى المحاولة مجدداً');
      setStatus('error');
    }
  }

  if (status === 'success') {
    return (
      <div className="bg-white rounded-card border border-gray-100 p-12 text-center shadow-sm">
        <div className="w-20 h-20 bg-green-50 rounded-full flex items-center justify-center mx-auto mb-6">
          <svg className="w-10 h-10 text-green-500" fill="none" stroke="currentColor" viewBox="0 0 24 24">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7" />
          </svg>
        </div>
        <h3 className="text-2xl font-bold text-heading font-montserrat mb-3">تم استقبال طلب الحجز بنجاح</h3>
        <p className="text-default font-cairo text-lg leading-relaxed">
          شكراً لثقتك بنا. سيتواصل معك فريقنا قريباً لتأكيد الموعد وإرشادك للخطوات التالية.
        </p>
      </div>
    );
  }

  const inputCls = 'w-full bg-light-bg border border-gray-100 rounded-xl px-5 py-4 text-sm focus:outline-none focus:ring-2 focus:ring-accent-500/40 focus:border-accent-500 transition-colors text-heading placeholder-gray-400 font-cairo shadow-sm';
  const selectCls = `${inputCls} cursor-pointer appearance-none`;

  return (
    <form onSubmit={onSubmit} className="space-y-6">

      {/* Name + Phone */}
      <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
        <div>
          <label className="block text-sm font-bold text-heading font-cairo mb-2">الاسم الكامل <span className="text-red-500">*</span></label>
          <input required name="name" value={form.name} onChange={onChange} placeholder="أدخل اسمك الكامل" className={inputCls} />
        </div>
        <div>
          <label className="block text-sm font-bold text-heading font-cairo mb-2">رقم الهاتف <span className="text-red-500">*</span></label>
          <input required name="phone" value={form.phone} onChange={onChange} placeholder="01xxxxxxxxx" className={inputCls} />
        </div>
      </div>

      {/* Email */}
      <div>
        <label className="block text-sm font-bold text-heading font-cairo mb-2">البريد الإلكتروني</label>
        <input type="email" name="email" value={form.email} onChange={onChange} placeholder="example@email.com" className={inputCls} />
      </div>

      {/* Hospital */}
      {hospitals.length > 0 && (
        <div>
          <label className="block text-sm font-bold text-heading font-cairo mb-2">المستشفى</label>
          <select name="hospitalId" value={form.hospitalId} onChange={onChange} className={selectCls}>
            <option value="">اختر المستشفى (اختياري)</option>
            {hospitals.map(h => <option key={h.id} value={h.id}>{t(h.name)}</option>)}
          </select>
        </div>
      )}

      {/* Medical Center */}
      {centers.length > 0 && (
        <div>
          <label className="block text-sm font-bold text-heading font-cairo mb-2">المركز الطبي</label>
          <select name="medicalCenterId" value={form.medicalCenterId} onChange={onChange} className={selectCls}>
            <option value="">اختر المركز الطبي (اختياري)</option>
            {centers.map(c => <option key={c.id} value={c.id}>{t(c.name)}</option>)}
          </select>
        </div>
      )}

      {/* Doctor */}
      {doctors.length > 0 && (
        <div>
          <label className="block text-sm font-bold text-heading font-cairo mb-2">الطبيب</label>
          <select name="doctorId" value={form.doctorId} onChange={onChange} className={selectCls}>
            <option value="">اختر الطبيب (اختياري)</option>
            {doctors.map(d => (
              <option key={d.id} value={d.id}>
                {t(d.name)}{d.specialty ? ` — ${t(d.specialty)}` : ''}
              </option>
            ))}
          </select>
        </div>
      )}

      {/* Preferred date */}
      <div>
        <label className="block text-sm font-bold text-heading font-cairo mb-2">التاريخ المفضل</label>
        <input
          type="date" name="preferredDate" value={form.preferredDate} onChange={onChange}
          min={new Date().toISOString().split('T')[0]}
          className={inputCls}
        />
      </div>

      {/* Dynamic Questions */}
      {questions.length > 0 && (
        <div className="border-t border-gray-100 pt-6 mt-6 space-y-6">
          <h3 className="text-lg font-bold text-heading font-montserrat mb-4">معلومات إضافية للمركز</h3>
          
          {questions.map((q: any) => (
            <div key={q.id}>
              <label className="block text-sm font-bold text-heading font-cairo mb-2">
                {t(q.questionText)} {q.isRequired && <span className="text-red-500">*</span>}
              </label>
              
              {q.questionType === 'text' && (
                <input
                  type="text"
                  required={q.isRequired}
                  value={answers[q.id] || ''}
                  onChange={(e) => onAnswerChange(q.id, e.target.value)}
                  className={inputCls}
                />
              )}
              
              {q.questionType === 'textarea' && (
                <textarea
                  required={q.isRequired}
                  value={answers[q.id] || ''}
                  onChange={(e) => onAnswerChange(q.id, e.target.value)}
                  rows={3}
                  className={`${inputCls} resize-none`}
                />
              )}
              
              {q.questionType === 'select' && (
                <select
                  required={q.isRequired}
                  value={answers[q.id] || ''}
                  onChange={(e) => onAnswerChange(q.id, e.target.value)}
                  className={selectCls}
                >
                  <option value="">اختر إجابة</option>
                  {q.options?.map((opt: any, i: number) => (
                    <option key={i} value={opt.value}>{t(opt.label)}</option>
                  ))}
                </select>
              )}
              
              {q.questionType === 'radio' && (
                <div className="space-y-2">
                  {q.options?.map((opt: any, i: number) => (
                    <label key={i} className="flex items-center gap-2 cursor-pointer">
                      <input
                        type="radio"
                        name={`question_${q.id}`}
                        value={opt.value}
                        required={q.isRequired}
                        checked={answers[q.id] === opt.value}
                        onChange={(e) => onAnswerChange(q.id, e.target.value)}
                        className="w-4 h-4 text-accent-500 border-gray-300 focus:ring-accent-500"
                      />
                      <span className="text-sm font-cairo text-heading">{t(opt.label)}</span>
                    </label>
                  ))}
                </div>
              )}
              
              {q.questionType === 'checkbox' && (
                <div className="space-y-2">
                  {q.options?.map((opt: any, i: number) => (
                    <label key={i} className="flex items-center gap-2 cursor-pointer">
                      <input
                        type="checkbox"
                        value={opt.value}
                        checked={(answers[q.id] || []).includes(opt.value)}
                        onChange={(e) => {
                          const val = e.target.value;
                          const current = answers[q.id] || [];
                          if (e.target.checked) {
                            onAnswerChange(q.id, [...current, val]);
                          } else {
                            onAnswerChange(q.id, current.filter((v: string) => v !== val));
                          }
                        }}
                        className="w-4 h-4 rounded text-accent-500 border-gray-300 focus:ring-accent-500"
                      />
                      <span className="text-sm font-cairo text-heading">{t(opt.label)}</span>
                    </label>
                  ))}
                  {/* Note: Checkbox group required validation is tricky in pure HTML, handled by UI mostly */}
                </div>
              )}
            </div>
          ))}
        </div>
      )}

      {/* Message */}
      <div>
        <label className="block text-sm font-bold text-heading font-cairo mb-2">ملاحظات إضافية</label>
        <textarea
          name="message" value={form.message} onChange={onChange}
          placeholder="أي معلومات إضافية تود مشاركتها..."
          rows={3}
          className={`${inputCls} resize-none`}
        />
      </div>

      {status === 'error' && (
        <p className="text-red-600 text-sm bg-red-50 px-4 py-3 rounded-xl">{errMsg}</p>
      )}

      <button
        type="submit"
        disabled={status === 'loading'}
        className="w-full bg-accent-500 hover:bg-accent-600 disabled:opacity-60 text-white font-bold py-4 rounded-pill transition-all font-cairo text-lg shadow-card-hover mt-4"
      >
        {status === 'loading' ? 'جارٍ الإرسال...' : 'تأكيد طلب الحجز'}
      </button>

      <p className="text-sm text-gray-400 text-center font-cairo mt-4">
        سيتواصل معك فريقنا خلال 24 ساعة لتأكيد موعدك
      </p>
    </form>
  );
}
