# deploy.ps1
# Automated Deployment Script for INSAN Healthcare Platform

$ErrorActionPreference = "Stop"

$ServerUser = "root"
$ServerHost = "vmi3466639.contaboserver.net" # ضع عنوان الـ IP الخاص بالسيرفر هنا إذا لم يعمل الدومين
$RemoteDir = "~/INSAN-Healthcare-Platform/website"

$Version = Get-Date -Format "yyyyMMdd-HHmmss"
$ArchiveName = "website-update-$Version.tar.gz"

Write-Host "Compressing files (excluding unnecessary files and configs)..." -ForegroundColor Cyan
tar -czvf $ArchiveName `
    --exclude="node_modules" `
    --exclude="dist" `
    --exclude=".next" `
    --exclude=".git" `
    --exclude=".env.production" `
    --exclude="docker-compose.prod.yml" `
    --exclude="*.tar.gz" `
    --exclude="*.zip" `
    -C . .

Write-Host "`nUploading update to server ($ServerHost)..." -ForegroundColor Cyan
Write-Host "You may be prompted for the server password." -ForegroundColor Yellow
scp $ArchiveName "${ServerUser}@${ServerHost}:${RemoteDir}/${ArchiveName}"

Write-Host "`nInstalling update and restarting Docker on server..." -ForegroundColor Cyan
# Using semi-colons and wrapping the remote command in quotes
$RemoteCommands = "cd $RemoteDir ; tar -xzvf $ArchiveName ; docker compose --env-file .env.production -f docker-compose.prod.yml up -d --build ; docker exec -i insan-api npx prisma db seed ; rm $ArchiveName"
ssh ${ServerUser}@${ServerHost} $RemoteCommands

Write-Host "`nCleaning up local temporary files..." -ForegroundColor Cyan
Remove-Item $ArchiveName

Write-Host "`nUpdate successfully deployed!" -ForegroundColor Green
